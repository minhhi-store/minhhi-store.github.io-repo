var QuangMinh = "mos"; // Không thay đổi. "mos"
var battDefaultColor = "#ffff00"; // tuỳ chọn màu ruột pin .
var chargingColor = "#64e782"; // Tuỳ chọn màu khi sạc pin .
var textcolor = "#fff"; // Tuỳ chọn màu chữ .
var BoxColor = "#222"; // Tuỳ chọn màu nền sóng wifi.
var iPhoneType = "auto"; // "iPhG", "iPhPlus" or "iPhX" or "iPhXMax" .Tuỳ chọn các máy ( iPhG = 6/7/8 ) , ( iPhPlus = Các máy Plus ) , ( iPhX và iPhXMax thì không cần nói 🤣, hoặc để ( auto ) , tự động căn chỉnh .

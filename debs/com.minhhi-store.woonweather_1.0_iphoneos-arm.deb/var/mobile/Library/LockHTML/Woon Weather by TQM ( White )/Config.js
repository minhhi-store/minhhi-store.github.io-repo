var twentyfourh = true; // true for 24 hr
var pad = true; // true to pad zero in hour
var QuangMinh1 = "black"; // Không thay đổi. "black"
var QuangMinh2 = "black"; // Không thay đổi. "black"
var iPhoneType = "auto"; // "iPhX" or "iPhXMax" .Tuỳ chọn các máy ( iPhX và iPhXMax thì không cần nói 🤣, hoặc để ( auto ) , tự động căn chỉnh .

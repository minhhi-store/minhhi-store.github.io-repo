var twentyfourhour = true; // Bặt hoặc tắt. Định dạng 24h
var pad = true; // Bặt hoặc tắt. Định dạng giờ vd.( 00 ) hoặc ( 0 )
var textcolor = "ffffff"; // Tuỳ chỉnh mã màu hiển thị. Mã mặc định  "6E6E6E" .
var scle = 1; // Tuỳ chỉnh kích cỡ
